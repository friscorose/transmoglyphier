# Unicode Character Database
# Date: 2023-08-28
# © 2023 Unicode®, Inc.
# Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
# For terms of use, see https://www.unicode.org/terms_of_use.html

This directory contains final data files for Unicode, Version 15.1

Public/emoji/15.1/

  emoji-data.txt
  emoji-variation-sequences.txt

The following related files are found in Unicode Emoji, Version 15.1

Public/15.1.0/ucd/emoji/

  emoji-sequences.txt
  emoji-zwj-sequences.txt
  emoji-test.txt

For documentation, see UTS #51 Unicode Emoji, Version 15.1
